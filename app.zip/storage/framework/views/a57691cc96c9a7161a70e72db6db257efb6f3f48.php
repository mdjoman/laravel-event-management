
<?php $__env->startSection('body'); ?>


<main id="main">

  <!-- ======= Breadcrumbs ======= -->
  <section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

      <div class="d-flex justify-content-between align-items-center">
        <h2>Model Details</h2>
        <ol>
          <li><a href="index.html">Home</a></li>
          <li><a href="portfolio.html">Our Model</a></li>
          <li>Model Details</li>
        </ol>
      </div>

    </div>
  </section><!-- End Breadcrumbs -->

  <!-- ======= Portfolio Details Section ======= -->
  <section id="portfolio-details" class="portfolio-details">
    <div class="container" data-aos="fade-up">

      <div class="row gy-4">

        <div class="col-lg-8">
          <div class="portfolio-details-slider swiper">
            <div class="swiper-wrapper align-items-center">

              <div class="swiper-slide">
                <img src="<?php echo e(asset($product->image)); ?>" alt="">
              </div>
              <?php $__currentLoopData = $subimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="swiper-slide">
                <img src="<?php echo e(asset($subimage->subimage)); ?>" alt="">
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="portfolio-info">
            <h3><?php echo e($product->model_name); ?></h3>
            <ul>
              <li><strong>Model Code:</strong> <?php echo e($product->model_code); ?></li>
              <li><strong>Model Height:</strong><?php echo e($product->model_hight); ?></li>
              <li><strong>Model Price:</strong><?php echo e($product->model_Price); ?>tk</li>
            </ul>
          </div>
          <div class="portfolio-description">

            <p>
              <?php echo e($product->lDescription); ?>


            </p>
            <div class="header-social-links d-flex">
              <a href="<?php echo e(route('contuct')); ?>">
                <h3 class="btn btn-success"> Contuct Us</h3>
              </a>
              <a href="<?php echo e($settingdetails->whatsapp); ?>" style="font-size: 32px;" class="linkedin"><i class="bu bi-whatsapp"></i></i></a>
              <a href="<?php echo e($settingdetails->twitter); ?>" style="font-size: 32px;" class="twitter"><i class="bu bi-twitter"></i></a>
              <a href="<?php echo e($settingdetails->instagram); ?>" style="font-size: 32px;" class="instagram"><i class="bu bi-instagram"></i></a>

            </div>


          </div>
        </div>

      </div>

    </div>
  </section><!-- End Portfolio Details Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('event.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/event/model-details.blade.php ENDPATH**/ ?>