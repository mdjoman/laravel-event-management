
<?php $__env->startSection('body'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add Model</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate Model</a>
    </div>
</div>   

 <div class="card card-body mb-5">
    <div class="container">
      <?php if($message = Session::get('message')): ?>
      <div class="alert alert-warning alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <?php echo e($message); ?>

      </div>
      <?php endif; ?>
            
      <div class="container">
        <form class="" action="<?php echo e(route ('cerate-model')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> 
            <div class="form-group row">
             <label class="col-sm-2 col-form-label" for="Categories Name"> Model Name:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="Categories Name" placeholder="Model Name...." name="model_name">
              <span class="text-danger"><?php echo e($errors->has('model_name') ? $errors->first('model_name') : ''); ?></span>
              </div>
         </div>
            <div class="form-group row">
             <label class="col-sm-2 col-form-label" for="Categories Name"> Category:</label>
              <div class="col-sm-10">
               <select class="form-control"  name="category_id" id="">
                   <option value="">----- Select Category Name-----</option>
                   <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
              <span class="text-danger"><?php echo e($errors->has('category_id') ? $errors->first('category_id') : ''); ?></span>
              </div>
           </div>
         
        
         <div class="form-group row">
             <label class="col-sm-2 col-form-label" for="Categories Name">Model Code:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="Categories Name" placeholder="'5620'" name="model_code">
              <span class="text-danger"><?php echo e($errors->has('model_code') ? $errors->first('model_code') : ''); ?></span>
              </div>
         </div>
         <div class="form-group row">
             <label class="col-sm-2 col-form-label" for="Categories Name">Model Hihgt:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="Categories Name" placeholder="5.5" name="model_hight">
              <span class="text-danger"><?php echo e($errors->has('model_hight') ? $errors->first('model_hight') : ''); ?></span>
              </div>
         </div>
         <div class="form-group row">
             <label class="col-sm-2 col-form-label" for="Categories Name">Model Price:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="Categories Name" placeholder="'5620'" name="model_Price">
              <span class="text-danger"><?php echo e($errors->has('model_Price') ? $errors->first('model_Price') : ''); ?></span>
              </div>
         </div>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label" for="Description"> Model Description:</label>
            <div class="col-sm-10">          
              <textarea   id="Categories Description"class="form-control" rows="4" name="lDescription"> Description</textarea>
              <span class="text-danger"><?php echo e($errors->has('lDescription') ? $errors->first('lDescription') : ''); ?></span>
            </div>
        </div>
      
        <div class="form-group row">
          <label class="col-sm-2 col-form-label " for="Description"> Model Image:</label>
            <div class="col-sm-10">
              <div class="form-check-inline ">
                  <label class="form-check-label "><input type="file" name="Image" accept="image/*" value=" "></label>
                  <span class="text-danger"><?php echo e($errors->has('Image') ? $errors->first('Image') : ''); ?></span>
              </div>
           </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-2 col-form-label " for="Description">  Model Sub-Image:</label>
            <div class="col-sm-10">
              <div class="form-check-inline ">
                  <label class="form-check-label "><input type="file" multiple accept="image/*" name="sImage[]" value=" "></label>
                  <span class="text-danger"><?php echo e($errors->has('sImage') ? $errors->first('sImage') : ''); ?></span>
              </div>
           </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-2 col-form-label " for="Description"> Publication status:</label>
            <div class="col-sm-10">
              <div class="form-check-inline ">
                  <label class="form-check-label "><input type="radio" name="status" value=" Published"> Published</label>
                  <span class="text-danger"><?php echo e($errors->has('status') ? $errors->first('status') : ''); ?></span>
              </div>
             <div class="form-check-inline ">
               <label class="form-check-label"> <input type="radio" name="status"value=" Unpublished" >  Unpublished</label>
               <span class="text-danger"><?php echo e($errors->has('status') ? $errors->first('status') : ''); ?></span>
             </div>
           </div>
        </div>
       
        <div class="form-group row ">        
          <div class=" col-sm-10">
            <button type="submit" class="btn btn-success">Creat New Model</button>
         </div>
        </div>
    </form>
    </div>
 </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/Admin/add-model.blade.php ENDPATH**/ ?>