
<?php $__env->startSection('body'); ?>


<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
                <h2>About</h2>
                <ol>
                    <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
                    <li>About</li>
                </ol>
            </div>

        </div>
    </section>
    <!-- End Breadcrumbs -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$settin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $settin->About; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- End About Section -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('event.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/event/about.blade.php ENDPATH**/ ?>