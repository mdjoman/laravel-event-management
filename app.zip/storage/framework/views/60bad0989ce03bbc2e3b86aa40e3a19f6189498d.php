
<?php $__env->startSection('body'); ?>


<main id="main">

<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Our Model</h2>
      <ol>
        <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
        <li>Our Model</li>
      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= Portfolio Section ======= -->
<section id="portfolio" class="portfolio">
    <div class="container">

      <div class="row" data-aos="fade-up">
        <div class="col-lg-12 d-flex justify-content-center">
          <ul id="portfolio-flters">
            <li data-filter="*" class="filter-active">All</li>
           
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
              <li data-filter=".filter-<?php echo e($categor->id); ?>"> <?php echo e($categor->name); ?></li>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>

      <div class="row portfolio-container" data-aos="fade-up">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo e($product->category_id); ?>">
          <img src="<?php echo e(asset($product->image)); ?>" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4><?php echo e($product->model_name); ?></h4>
            <p><?php echo e($product->model_Price); ?> tk</p>
            <a href="<?php echo e(asset($product->image)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="App 1"><i class="bx bx-plus"></i></a>
            <a href="<?php echo e(route('model-details', [ 'id' => $product->id])); ?>" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
          </div>
        </div>

        <?php if($loop->iteration == 8): ?>
        <?php break; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>

    </div>
  </section><!-- End Portfolio Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('event.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/event/model.blade.php ENDPATH**/ ?>