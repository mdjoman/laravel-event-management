
<?php $__env->startSection('body'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
       
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-nanage fa-sm text-white-50"></i> Manage Product</a>
    </div>
</div>  
<div class="row">
    <div class="col-sm-12 container">
       <div class="card card-body rounded-0">
       <?php if($message = Session::get('message')): ?>
      <div class="alert alert-warning alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <?php echo e($message); ?>

      </div>
      <?php endif; ?>
           <div class="table-responsive ">
               <table  class="table table-bordered">
                   <tr>
                    <th>SL.NO</th>
                    <th>Model image</th>
                    <th>Model Name</th>
                    <th>Model category</th>
                    <th>Model Code</th>
                    <th>Model status</th>
                    <th>Action</th>
                   </tr>
                    
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                   <tr>
                       <td><?php echo e($loop->iteration); ?></td>
                       <td><img class="center" src="<?php echo e($product->image); ?>" width="70px" height="70px" alt=""></td> 
                       <td><?php echo e($product->model_name); ?></td>
                       <td><?php echo e($product->category->name); ?></td>
                       <td><?php echo e($product->model_code); ?></td>
                       <td><?php echo e($product->status); ?></td>
                     
                 

                       <td>
                           <a href="<?php echo e(route('view-model', [ 'id' => $product->id])); ?>"class="btn btn-warning btn-sm">View</a>
                           <a href="<?php echo e(route('edit-model', [ 'id' => $product->id])); ?>"class="btn btn-success btn-sm">Edite</a>
                           <a href="<?php echo e(route('view-model', [ 'id' => $product->id])); ?>"class="btn btn-danger btn-sm">Delete</a>
                          
                       </td>
                   </tr>
              
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
           </div>
       </div>
    </div>
</div> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/Admin/manage-model.blade.php ENDPATH**/ ?>