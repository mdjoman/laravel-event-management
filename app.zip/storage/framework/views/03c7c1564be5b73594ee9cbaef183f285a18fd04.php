
<?php $__env->startSection('body'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Categories</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>
</div>  
<div class="row">
    <div class="col-sm-12 container">
       <div class="card card-body rounded-0">
       <div class="container">
      <?php if($message = Session::get('message')): ?>
      <div class="alert alert-warning alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <?php echo e($message); ?>

      </div>
      <?php endif; ?>
           <div class="table-responsive ">
               <table  class="table table-bordered">
                   <tr>
                    <th>SL.NO</th>
                    <th>Category Name:</th>
                    <th>Category Description</th>
                    <th>Publication Status</th>
                    <th>Action</th>
                   </tr>
                   
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($loop->iteration); ?></td>
                       <td><?php echo e($category->name); ?></td>
                       <td><?php echo e($category->Description); ?></td>
                       <td><?php echo e($category->status); ?></td>
                       <td>
                           <a href="<?php echo e(route('edit-category', [ 'id' => $category->id])); ?>"class="btn btn-success">Edite</a>
                           <a href="<?php echo e(route('edit-category', [ 'id' => $category->id])); ?>"class="btn btn-danger">Delete</a>
                       </td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
           </div>
       </div>
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/bddating/public_html/resources/views/Admin/manage-categories.blade.php ENDPATH**/ ?>